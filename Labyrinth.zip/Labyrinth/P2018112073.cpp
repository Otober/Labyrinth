#include "P2018112073.h"
#include "Maze.h"
#include "GameManager.h"
P2018112073::P2018112073() {
	
}
void P2018112073::gameStart(Point player/*������ġ*/, int height, int width) {
	Point currpoint = player;
	GameManager gamemanager;
	gamemanager.init();


}
void DFS(int row, int col, int n) {

}
Action P2018112073::nextMove() {
	return Action::MOVE_DOWN;
}
void P2018112073::ableToMove(Point point, Point prevPoint) {}
void P2018112073::notAbleToMove(Point point) {}